# IRIS

Iris is a browser based E-Reading application housing a library of both E-Magazines and E-Books. Featuring dynamically loading images, and a functioning login accompanied with server side data storage. 

# Walkthrough 

![1544553561918](C:\Users\pburk\OneDrive\Desktop\documentation\homepage.png)



Here is the home page, which contains a top navigation bar. Clicking on the Pages button reveals a drop down menu.

![dropdown](C:\Users\pburk\OneDrive\Desktop\documentation\dropdown.png)

Hitting Login reveals the login screen at the bottom of the page where a user can enter their information.

![login](C:\Users\pburk\OneDrive\Desktop\documentation\login.png)

If a user does not have an account they can hit register, which changes the login section into a registration area.

![register](C:\Users\pburk\OneDrive\Desktop\documentation\register.png)

Once a user has an account they can log in and view their profile. Clicking the profile button reveals recommended E-Magazines and E-Books below; currently with placeholder images and  text to make way for actual E-Texts.

![E-Books](C:\Users\pburk\OneDrive\Desktop\documentation\E-Books.png)

# Usage

*Put any useful code snippets here*

# Support

Contact through twitter @IRISpublishing

# Roadmap

- Enable SSL (secure socket layers) for data security
- Set up and online store to allow users to make subscriptions to hots
- Allow users to personalize their profile and settings to allow a more user friendly experience
- Create a form to upload new EPUBs directly to the server, instead of manual addition
- Set up an email server to better utilize the notification program, and send personalized recommendations to user with Pug.js

# Project Status

This project is currently still under development as of 12.18.18. 